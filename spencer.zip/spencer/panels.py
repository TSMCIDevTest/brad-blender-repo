import bpy

class SpencerStatPanel(bpy.types.Panel):
    bl_label = 'Statsisic'
    bl_idname = 'OBJECT_PT_statsisic'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Item'
    
    @classmethod
    def pull(self, context):
        active_object = context.view_layer.objects.active
        if active_object is not None:
            return True
        else:
            return False
    
    def draw(self, context):
        layout = self.layout
        active_object = context.view_layer.objects.active
        name = active_object.name
        layout.label(text=name, icon='OBJECT_DATA')
        modifiers_count = str(len(active_object.modifiers)) + ' modifiers'
        layout.label(text=modifiers_count, icon='MODIFIER')
        
        layout.separator()
        row = layout.row(align=True)
        row.prop(active_object, 'hide_viewport', text='Viewport')
        row.prop(active_object, 'hide_render', text='Render')

class SpencerFavoratesPanel(bpy.types.Panel):
    bl_label = 'Favorates'
    bl_idname = 'OBJECT_PT_favorates'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Item'
    
    def draw(self, context):
        layout = self.layout
        operator = layout.operator('object.transform_apply', text='Apply Object Scale')
        operator.location = False
        operator.rotation = False
        operator.scale = True
        operator = layout.operator('object.duplicates_make_real')
        operator.use_base_parent = False
        operator.use_hierarchy = True
def register():
    bpy.utils.register_class(SpencerStatPanel)
    bpy.utils.register_class(SpencerFavoratesPanel)
    
def unregister():
    bpy.utils.unregister_class(SpencerStatPanel)
    bpy.utils.unregister_class(SpencerFavoratesPanel)
    
if __name__ == "__main__":
    register()